****
Text
****

.. toctree::
   :maxdepth: 2

   debug_print
   datetime_strings
   note
   shape
   text_in_mk2
   viewer_text_mk3
   stethoscope_v28
