**********
Quaternion
**********

.. toctree::
   :maxdepth: 2

   quaternion_in
   quaternion_out
   quaternion_math
