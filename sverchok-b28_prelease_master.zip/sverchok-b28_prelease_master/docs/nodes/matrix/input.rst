Matrix Input
============