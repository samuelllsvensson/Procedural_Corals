Matrix In & Out
===============