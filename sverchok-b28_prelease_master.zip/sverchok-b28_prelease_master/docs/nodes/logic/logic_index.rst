*****
Logic
*****

.. toctree::
   :maxdepth: 2

   logic_node
   neuro_elman
   switch
   input_switch_mod
   custom_switcher
