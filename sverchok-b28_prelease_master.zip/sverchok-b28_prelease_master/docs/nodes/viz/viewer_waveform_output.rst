Viewer Waveform
===============

Functionality
-------------

This node will take datastream inputs and allow you write an audio file to disk,
and display the waveform in nodeview on a oscilloscope like display.