Vector X Doubles
================

This node simple remove double vertices from the input.

Inputs and Outputs
------------------

**inputs** are vertices and list of vertices.

**outputs** are vertices and list of vertices.

Example
-------

..image:: https://cloud.githubusercontent.com/assets/1275858/24463951/98383630-14a8-11e7-8653-178335ec576b.png
