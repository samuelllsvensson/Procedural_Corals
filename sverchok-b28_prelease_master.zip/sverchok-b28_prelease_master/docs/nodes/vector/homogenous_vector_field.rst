Vector P Field
==============

Functionality
-------------


makes a 3d vector grid, with option to slightly randomize (with seed) each vertex, and apply a 'remove doubles' distance to the product.

