Vector Drop
===========

Functionality
-------------

Reverse operation to Matrix apply. 
If matrix apply adding all transformations to vertices.
Than vector drop substract matrix from vertices.

Inputs
------

**Vertices** - Vectors input to transform
**Matrix** - Matrix to substract from vertices

Outputs
-------

**Vertices** - vertices

Examples
--------

.. image:: https://cloud.githubusercontent.com/assets/5783432/4905667/60572716-6452-11e4-98f3-296387ada7a9.png
  :alt: vector drop
