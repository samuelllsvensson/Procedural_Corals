**********
Generators
**********

.. toctree::
   :maxdepth: 2

   basic_3pt_arc
   basic_spline
   quad_spline
   box
   bricks
   circle
   cylinder_mk2
   image
   line_mk3
   ngon
   plane_mk2
   random_vector_mk2
   script1_lite
   sphere
   icosphere
   suzanne
   torus
   torusKnot
   formula_shape
