Suzanne Node
============

Functionality
-------------

This node creates Suzanne (Monkey) primitive, which is well-known Blender mascot.

Inputs
------

This node has no inputs.

Parameters
----------

This node has no parameters.

Outputs
-------

This node has the following outputs:

- **Vertices**
- **Edges**
- **Faces**

Example of usage
----------------

Simple example:

.. image:: https://user-images.githubusercontent.com/284644/33239125-604fe7a8-d2bd-11e7-944d-a0894813cb65.png

