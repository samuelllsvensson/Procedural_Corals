SNLite Docs
-----------

There's no rst for this at present, please read the preliminary (but comprehensive) docs on :

https://github.com/nortikin/sverchok/issues/942
