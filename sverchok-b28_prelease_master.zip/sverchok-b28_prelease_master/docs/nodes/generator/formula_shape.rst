Formula Shape
=============

Usage
-----

.. image:: https://cloud.githubusercontent.com/assets/7894950/5124673/7b9ddd82-70cb-11e4-8af6-47a8f4aefc76.png
