Delete Loose
============

Functionality
-------------

Delete Loose vertices, that not belong to edges or polygons that plugged in.

Inputs
------

- **Vertices**
- **PolyEdge**

Outputs
-------

- **Vertices** - filtered
- **PolyEdge**

Examples of usage
-----------------

Simple:

.. image:: https://cloud.githubusercontent.com/assets/5783432/18611195/3b47ce74-7d43-11e6-8d05-335919636b2b.png
