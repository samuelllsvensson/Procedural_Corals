***************
Modifier Change
***************

.. toctree::
   :maxdepth: 2

   bevel
   subdivide
   subdivide_lite
   unsubdivide
   smooth
   delete_loose
   edges_intersect_mk2
   extrude_edges_mk2
   extrude_separate
   extrude_separate_lite
   extrude_region
   holes_fill
   mesh_join
   mesh_separate
   objects_along_edge
   offset
   polygons_boom
   polygons_to_edges
   recalc_normals
   remove_doubles
   triangulate
   planar_faces
   split_faces
   vertices_mask
   make_monotone
   dissolve_faces_2d
   planar_edgenet_to_polygons
   pulga_physics
   inset_faces
