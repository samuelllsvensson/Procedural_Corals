Unsubdivide node
========

Functionality
-------------

Example of usage
----------------
.. image:: https://user-images.githubusercontent.com/22656834/38300761-17c6615a-3817-11e8-8c8b-e94f1d62cc5a.png
