Extrude separate faces lite
========

Functionality
-------------



Inputs
------

- **Vertices**
- **polygons**
- **Mask**
- **Matrix**

Outputs
-------

- **Vertices**.
- **Edges**.
- **Polygons**.
- **ExtrudedPolys**.
- **OtherPolys**.

Example of usage
----------------
.. image:: https://user-images.githubusercontent.com/22656834/37788985-9a755b12-2e24-11e8-862c-d048fb8fc2d3.png
