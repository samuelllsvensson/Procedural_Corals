*******
Objects
*******

.. toctree::
   :maxdepth: 2

   get_asset_properties
   lattice_analyzer
   armature_analyzer
   sample_uv_color
   select_mesh_verts
   weightsmk2
   getsetprop
   assign_materials
   material_index

