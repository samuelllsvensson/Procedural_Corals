Socket Converter
================

Functionality
-------------

Converts sockets types if something go wrong or your node too alpha

Inputs
------

**data**

Outputs
-------

**vertices**, **data**, **matrices**
