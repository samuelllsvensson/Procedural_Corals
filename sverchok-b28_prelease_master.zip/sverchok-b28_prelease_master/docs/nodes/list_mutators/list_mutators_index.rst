*************
List Mutators
*************

.. toctree::
   :maxdepth: 2

   modifier
   polygon_sort
   combinatorics
