*************
Modifier Make
*************

.. toctree::
   :maxdepth: 2

   bisect
   cross_section
   edges_adaptative
   lathe
   matrix_tube
   pipe_tubes
   adaptive_polygons_mk2
   solidify
   uv_connect
   voronoi_2d
   delaunay_2d
   wafel
   framework
   wireframe
   offset_line
   bevel_curve
   contour2D
   fractal_curve
   convex_hull_mk2
   dual_mesh
   random_points_on_mesh
   delaunay_2d_cdt
