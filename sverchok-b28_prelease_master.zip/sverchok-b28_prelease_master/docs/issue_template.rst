## Problem statement

Please describe your problem here.

## Steps to reproduce

1. 
2. 
3. 

## Expected result

What did you expect to see as a result of those steps?

## Actual result

What did you actually get?

## Sverchok version

This is especially important for installation-related issues. Please specify how do you install Sverchok: from sverchok-master.zip from github, or from release zip file, or from cloned git repo.

