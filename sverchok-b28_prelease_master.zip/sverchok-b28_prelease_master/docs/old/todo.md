
== NEW TODO lists are in github: ==

* zeffii https://github.com/nortikin/sverchok/issues/118
* nikitron https://github.com/nortikin/sverchok/issues/120
* ly https://github.com/nortikin/sverchok/issues/119

create your own
