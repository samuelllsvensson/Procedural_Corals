Math
====

This is the mk1 version. Go to scalar_mk2.rst for a description of this node.
