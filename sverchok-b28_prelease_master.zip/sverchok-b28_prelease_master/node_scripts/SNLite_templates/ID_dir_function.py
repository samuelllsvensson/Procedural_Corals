"""
in obj o d=[[]] n=0
out stuff     v
"""
#stuff = [' '.join(dir(obj))]
stuff = dir(obj[0])
